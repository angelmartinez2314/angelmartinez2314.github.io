---
name: Pregunta
about: Si tienes dudas comunicate con nosotros a través de redes sociales
---

# Preguntas, inquietudes

Si tienes dudas personales por favor contácteme usando [telegram](https://telegram.me/scot3004), [facebook](https://www.facebook.com/scot3004) Si no tienes acceso a ninguna de las plataformas antes nombradas dejame un mensaje en el [formulario de contacto](https://www.secorto.com/contacto/) de mi página web
