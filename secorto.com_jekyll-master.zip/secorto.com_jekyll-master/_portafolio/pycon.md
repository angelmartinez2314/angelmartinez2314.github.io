---
title: PyCon
header:
  image: /img/uploads/pycon-pybaq-2019.jpg
  teaser: /img/uploads/pycon-pybaq-2019.jpg
sidebar:
  - title: '2020'
    text: Volunteer
    image_alt: Pycon 2020
    image: /img/uploads/pycon2020.png
  - image: /img/uploads/logo.svg
    image_alt: Pycon 2019
    text: Volunteer
    title: '2019'
  - image: /img/uploads/logo_pycon_2018.svg
    image_alt: PyCon 2018
    text: Volunteer
    title: '2018'
gallery:
  - alt: Equipo Python Barranquilla Pycon 2019
    image_path: /img/uploads/pycon-pybaq-2019.jpg
    url: /img/uploads/pycon-pybaq-2019.jpg
  - alt: Iniciando PyCon
    image_path: /img/uploads/51762709_2183760241688566_7771308469558181888_n.jpg
    url: /img/uploads/51762709_2183760241688566_7771308469558181888_n.jpg
---
La PyCon es un evento realizado por la comunidad Python. En colombia se realiza una vez al año el segundo fin de semana de febrero.

He tenido la oportunidad de apoyar en logistica los años 2018 y 2019.
