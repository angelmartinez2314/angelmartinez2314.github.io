---
title: Screenshoots de mi Chakra
tags:
thumbnail: https://lh3.googleusercontent.com/-o5H766pfSi8/TXBjmjrondI/AAAAAAAAAIQ/wjKl0Oem7Dk/s72-c/snapshot1.png
blogger_id: tag:blogger.com,1999:blog-3290987933179858425.post-5426752598872988161
blogger_orig_url: http://scot3004.blogspot.com/2011/03/screenshoots-de-mi-chakra-bueno-en.html
category: linux

gallery:
  - url: img/screenshoots/openbox.png
    image_path: img/screenshoots/openbox.png
    alt: "Openbox + Nitrogen + Kmixer + KNetworkManager + Conky + Krunner + Tint2"
  - url: img/screenshoots/lxde.png
    image_path: img/screenshoots/lxde.png
    alt: "Lxde + Openbox + KnetworkManager + repos de arch"
  - url: img/screenshoots/kde.png
    image_path: img/screenshoots/kde.png
    alt: "KDE"

---

Screenshoots de mi Linux
Un toque personal de lo que se puede hacer con GNU/Linux
un tiempo en hacer el escritorio mas agradable es un tiempo de aprendizaje
Openbox
LXDE
escritorios de por si hermosos a continuación las capturas de ellos

{% include gallery caption="Capturas de pantalla" %}
