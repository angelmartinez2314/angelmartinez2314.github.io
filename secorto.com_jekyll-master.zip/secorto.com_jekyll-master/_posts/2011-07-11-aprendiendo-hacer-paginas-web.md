---
title: Aprendiendo a hacer paginas web
tags:
- html
- aprendizaje
blogger_id: tag:blogger.com,1999:blog-3290987933179858425.post-6888018474731877278
blogger_orig_url: http://scot3004.blogspot.com/2011/07/aprendiendo-hacer-paginas-web.html
category: dev
---

Como todo lo que se nos presenta en frente necesitamos aprender, el crear una pagina web no hace la excepción, si te interesa, como en todo debes saber donde encontrar la información pertinente.

a continuación algunos enlaces a paginas que me han servido para aprender estas tecnologías:

[http://desarrolloweb.com/](http://desarrolloweb.com/) es una interesante pagina en español donde encontraras manuales, videotutoriales y una que otra curiosidad, recomendable inicies desde 0 o tengas experiencia, puede ser un poco confusa al principio pero tiene unos manuales excelentes.
[http://www.w3schools.com](http://www.w3schools.com/) esta me gusta por que es clara y concisa el problema esta principalmente para los hispanohablantes, pues esta en ingles pero si sabemos al menos algunas peculiaridades de este idioma podremos defendernos con esta, tiene teoría y podemos experimentar con los ejemplos que allí colocan, sea modificando el código o solo viendo.
[http://www.webestilo.com](http://www.webestilo.com/) esta fue una de las primera que encontré, apoyado en esta fue que cree mi primera pagina web.
[http://www.css3maker.com/](http://www.css3maker.com/) esta pagina sirve para facilitarnos un poco la creación de algunos elementos css3
[http://notepad-plus-plus.org/](http://notepad-plus-plus.org/) mi editor de texto para win, interesante por la cantidad de lenguaje que soporta, tiene intellisense para html, seamos realistas eso influye bastante, resalta el inicio y fin de las etiquetas excelente para aprender, pero como tal no es un ide, asi que no esperen un editor gráfico.
[http://netbeans.org/](http://netbeans.org/) no se que tengo con este ide, pero no esta de mas mencionarlo especialmente si lo que quieres hacer incluye java, en html no es precisamente lo mejor, pero al menos da la pelea, en php encontré algunas curiosidades que me han facilitado la vida, claro para alguien que usa este ide en java era de esperarse que tuviese ciertas expectativas con el intellisense, o la creación automática de contractor getter y setter, mejor dicho lo relacionado con la POO.

Actualización:
En lugar de netbeans uso [Visual Studio Code](https://code.visualstudio.com/)

Existen Plataformas como [Udemy](https://www.udemy.com/), [PluralSight](https://app.pluralsight.com) donde se puede aprender a través de videos
