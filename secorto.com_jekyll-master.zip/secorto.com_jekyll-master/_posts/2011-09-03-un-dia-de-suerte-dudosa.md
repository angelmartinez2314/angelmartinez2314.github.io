---
title: Un día de suerte dudosa
tags:
blogger_id: tag:blogger.com,1999:blog-3290987933179858425.post-3739817379099048302
blogger_orig_url: http://scot3004.blogspot.com/2011/09/un-dia-de-suerte-dudosa.html
category: random
---

Un dia donde la madrugada fue tranquila
un estado de animo cambiante según la hora situaciones algo estresantes
buses que pasan al frente mientras camino, donde el siguiente de cada uno pasa con espacio para sentarse
exposiciones preparadas al flote, resultados buenos
pocas comidas, demasiada llenura
en fin uno de esos dias donde uno dice que paso aquí

{{ site.excerpt_separator }}

Inicio
4:30 am: mi mama se levanta, ella tiene que trabajar, en eso me levanto al ver que el bombillo de su cuarto esta encendido y tengo clases temprano
hago la respectiva rutina matinal, salimos a tomar el bus
primer bus que se pasa en la cara, que vaina, al fin y al cabo mi mama termino tomando taxi, yo por mi parte tome otro bus que paso 10 min después, con bastante espacio para ir sentado
llego a la U, wow nadie ha llegado, milagro, llegue temprano una clase un viernes, pero al momento de entrar no tenia el carne. No podía entrar, me toco esperar que llegara el que me tenia el carne, la persona encargada de la sala, tanto llegar temprano y entro media hora tarde a la clase.
llego a la clase me doy cuenta oh no están exponiendo
yo internamente diciendo estoy llorado, no prepare la mia. luego alguien expone, me doy cuenta que se algo parecido a es tema, claro allí esta la clave, pido el documento base de donde se basaban las exposiciones, allí mismo inicia la preparación  de la misma, hay un inconveniente yo solo no quería pasar, llego un compañero que estaba en la misma situación allí mismo iniciamos, que suerte la expo salio bastante bien, no podia contener la alegría
termina la clase, decía que cosas, aun asi apenas eran las 9 de la mañana, quedaba mas por hacer
hubo reunion de semillero, todo normal
mediodía, aun sigue la llenura del dia anterior, desayuno en espera
inicio el taller para presentar en la noche me topo con gente interrumpiendo, pero al menos aligeraron el estrés que hacer el mismo ocasiona
finalizo taller 3:20pm, y eso que solo eran 7 puntos
inicio la creación de diapositivas para la expo de la noche, al menos con esta la preparación fue mayor. pero mi compañera no tenia idea de que exponer, y tampoco quería hacerlo solo pude decirle ni de vaina expongo solo no te pongas las pilas mas bien
inicia la clase, inician exposiciones, mi compañera intenta convencer al profesor, uff el mismo la convence que tenia que exponer, bueno que importa, al menos entro en razón, subimos un rato a biblioteca le dije las bases de lo que había que decir, todo esto por que mas que exponer, lo que me espanta mas es exponer solo, total la exposición sale bien, afortunadamente para mi.
salgo con otro compañero a tomar el bus de transmetro para finalizar, pero que va cuando reviso, no tenia el carne, me lo entregaron, pero me toco entregarlo cuando entre a sala asi que otra vez sin carne, luego de lo sucedido en la mañana no quería dejarlo, total que me devuelvo busco el carne y salgo ya con el carne a tomar el bus, veo que uno esta en el semáforo, pero el condenado chófer no quiso abrir la puerta, con eso me condeno a tener que  tomar otro bus, pasa la buseta que iba detrás de este, cojo la buseta, luego llega la buseta a la estación, pero resulta que mi tarjeta esta con saldo negativo, el CATI (cosito pa cargar la tarjeta) no me tomaba el billete, total que me ayudaron con el mismo, en ese trajín se ha sabido pasar otro bus de transmetro en mi cara, en fin entro a la estación al fin, pasa otro bus, me entero que el que se me paso iba full y este otro tenia puestos disponible, algo interesante hasta ahora, llego a buscar mi ultimo transbordo, en eso sale la ruta que debería  tomar, pude decir, eche que todas las rutas en mi cara!!!! total allí llego otro, tome ese otro, tenia asiento, aunque esta vez no fue tanto el impacto, pues el que había salido antes también tenia puestos, total llegue a mi casa al fin a comer y dormir, que iba a querer  tomar PC, en lo único que pensaba era en comer y dormir y asi acabo un dia de lo mas raro!!
