---
title: Windows o Linux
tags:
blogger_id: tag:blogger.com,1999:blog-3290987933179858425.post-8542088883887158315
blogger_orig_url: http://scot3004.blogspot.com/2010/10/windows-o-linux.html
category: linux
---

Algunos afirman que Windows es mejor, otros que Linux.

La realidad es la siguiente, las personas se ajustan a lo que tienen cerca a lo que fueron educadas, la realidad es que en los colegios donde estudie informática era básicamente Windows y Office, esto es uno de las cosas que ha ayudado a la expansión de Windows, en realidad vine a aprender sobre Linux gracias a los compañeros de la universidad.

{{ site.split }}

Resalto en Windows su Interfaz Gráfica de Usuario,he notado que es de fácil aprendizaje, y bastante consistente, además de esto Windows ofrece un catalogo básico (honestamente me parece muy básico), el soporte de drivers es bueno, Windows es respaldado por muchas grandes empresas en el mundo de la informática, ensambladores de hardware desarrolladores de juegos en fin...

Respecto a Linux que a pesar de ser un sistema operativo relativamente nuevo tiene una gran comunidad esforzada a mejorarlo, esta bien, existen muchas distribuciones, y cada una con su comunidad pero al fin de cuentas es una sola, una gran comunidad que se ayuda entre si, desde las distribuciones mas ligeras a las mas pesadas, Linux le ofrece al usuario la posibilidad de personalizarlo a niveles que Windows no puede llegar, llevando a que el usuario corriente se sienta agobiado, por eso es que muchos tienden a no escoger linux.

En lo personal conozco las siguientes distribuciones:

Ubuntu
: Fácil de usar, interfaz gnome, division en dos paneles, perfecta para uso corriente, ideal para iniciar a usar Linux (en lo personal fue la primera distribución que conocí)

Linux Mint
: Excelente, soportada por la comunidad viene lista para usar, al ser derivada de Ubuntu comparte muchas características con esta.

Slitaz
: Liviana (30mb), y no sacrifica los paquetes que esta contiene, una gran (bueno pequeña) opción para sacar a relucir los equipos no tan nuevos, no se confíen puede correr en equipos recientes a gran velocidad.

ArchLinux
: honestamente la distribución que he tocado con mayor nivel, es la propia para los que les gustan los retos, la personalización es uno de sus principales fuertes, pues posee un gestor de paquetes poderoso.

No apoyen la piratería, compren Windows o usen Linux
