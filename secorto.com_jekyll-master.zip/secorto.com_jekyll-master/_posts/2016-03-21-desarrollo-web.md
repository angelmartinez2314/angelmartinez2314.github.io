---
title:  "Desarrollo web"
category: dev
---

El desarrollo web presenta desafios para aquellos que escogen tan linda y demandada profesión

El dia a dia de un desarrollador web parece ser solo sentarse en su maquina y escribir codigo
la realidad es que esta lleno de momentos satisfactorio
 donde todo sale de maravilla y momentos donde desearias cambiar de profesión
aun asi es una experiencia agradable aprender de todas las cosas que sucedieron mientras llegaste a tu objetivo
