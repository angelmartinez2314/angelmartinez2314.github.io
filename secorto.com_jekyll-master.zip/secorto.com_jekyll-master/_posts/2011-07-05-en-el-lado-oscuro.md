---
title: En el lado oscuro
tags:
modified_time: '2011-07-05T19:53:33.426-05:00'
blogger_id: tag:blogger.com,1999:blog-3290987933179858425.post-2947760038765923639
blogger_orig_url: http://scot3004.blogspot.com/2011/07/en-el-lado-oscuro.html
category: random
---

Vacaciones, uno dice este man se fue a pasear,
pero no es asi, mi personalidad, que emana curiosidad a donde va delata que en estos dias el código no descansa,
a menos que salga de viaje en familia.

Lo único que me desespera del periodo de vacaciones es el hecho de no poder ver a algunas personas, por que están muy lejos, siente uno que no podrá hablar con ellos comentar lo que hago o lo que hacen.

Pero que se hace las cosas son asi, por mucho que uno intente decir que no,
siempre queremos ver a las personas apreciamos siempre tendremos a querer tenerlas al lado,
en fin solo se que todo esto es psicológico, pero hay gente que extraño las cosas son asi,
no puedo evitarlo, pero se que donde están, la están pasando bien aun asi,
me quedo en el lado oscuro un rato mas....
