---
title: Typeracer
tags:
thumbnail: http://3.bp.blogspot.com/-AbKDaOs8rOk/TiURJQaF76I/AAAAAAAAAM0/k4OTThXsLew/s72-c/ContrincanteGana.png
blogger_id: tag:blogger.com,1999:blog-3290987933179858425.post-4875205843975611519
blogger_orig_url: http://scot3004.blogspot.com/2011/07/typeracer.html
category: juegos
---

Bueno hoy algo de publicidad, buscando en internet algún juego aplicable a la educación encontre esta entretenida idea, un juego de mecanografía, de aceleración, o arrancon donde la velocidad que lleve nuestro vehículo, sera la velocidad con la cual tecleamos, lo interesante del juego es poder jugar con otras personas o practicar, en este me enfrente a un amigo que invite, que admito teclea mucho mas rápido, de echo es una de las razones por las que casi no publico en mi blog, acá no se muestra pero me patean las tildes, especialmente por que cambian dependiendo de la distribución de teclado que se use, pero en fin un recomendado, adelante unas capturas del mismo, creanme cuando les digo, por una tilde pueden perder valiosos segundos

![Contrincante gana](//3.bp.blogspot.com/-AbKDaOs8rOk/TiURJQaF76I/AAAAAAAAAM0/k4OTThXsLew/s640/ContrincanteGana.png)
*Claro, me dejaron botado*

![Estadísticas](//2.bp.blogspot.com/-1PYefFXXP8o/TiURKEOAjRI/AAAAAAAAAM4/IPPxJ-Z3VzE/s640/Estadisticas.png)
*Sube y baja, sube y baja, tampoco es que pueda teclear muy rapido*

![Fin de la cadena](//4.bp.blogspot.com/-bV-brFU1Afs/TiURLAgGkAI/AAAAAAAAAM8/Hwfh0XhgRBU/s640/Fin+Carrera.png)
*Gane!!!, espera, acaso no me esperaron, OUCH!!!*

![Fin multi-jugador](//3.bp.blogspot.com/-fkLcvp1HMSk/TiURMSlJf_I/AAAAAAAAANA/Rk7_QJu8wGA/s640/Fin+Multi.png)
*Ouch, eso dolio*

![Información contrincante](//3.bp.blogspot.com/-s4fEPZCwu9Q/TiURNC2LJEI/AAAAAAAAANE/7eru-63j4-A/s640/info+contrincante.png)
*MMM contrincante fuerte, bueno, vamos pa esa*

![Inicio carrera](//2.bp.blogspot.com/-k7qRcuD_lUs/TiUROFJoGrI/AAAAAAAAANI/9um-S6YCJ2E/s640/Inicio+Carrera.png)
*En sus marcas, listos, fuera*

![Inicio multijugador](//1.bp.blogspot.com/-d4ZtcEdKT_g/TiURPMeNH6I/AAAAAAAAANM/F0cNnfozc5w/s640/Inicio+Multi.png)
*Bueno podemos chatear antes de iniciar*

![Fin de la carrera gana](//3.bp.blogspot.com/-nA-ZqXm-Vqo/TiUSbV0oKII/AAAAAAAAANU/EEKvZY3MkwA/s640/fin+practica.png)
*Bueno al menos no me la tire tan feo*

![Practica](//4.bp.blogspot.com/-UFuNRw_Blag/TiUVh9X5AnI/AAAAAAAAANg/3G1T2KcOSms/s1600/15333530841_G6c38.jpg)
