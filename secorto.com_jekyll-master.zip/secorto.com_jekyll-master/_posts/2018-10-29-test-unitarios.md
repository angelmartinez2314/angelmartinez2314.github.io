---
title: Test unitarios
category: dev
tags:
  - presentaciones
  - testing
toc: false
toc_sticky: false
thumbnail: /img/uploads/screenshot_20181029_235214.png
---
[![Test + Mock](/img/uploads/screenshot_20181029_235214.png)](https://scot3004.github.io/pymock)

En la presentación se puede observar como realizar la creación de pruebas unitarias usando sentinels mock y stubs, esta fue realizada en el [meetup de pybaq en enero de 2017](https://www.meetup.com/es-ES/pythonbaq/events/237160306/)
