---
layout: single
extra_js: checktop();
toc: true
---

# Quien Soy

Soy un Barranquillero de nacimiento encariñado con las ciudades de Medellín, Santa Marta y Cartagena.

Mi nickname Scot3004 se origina de mis iniciales junto a mi fecha de nacimiento. En algunos videojuegos suelo usar el apodo secorto, que en esencia son mis iniciales.

En mi bicicleta he tenido el placer de recorrer Barranquilla, Cartagena, Santa marta y Medellín, este último gracias al sistema de bicicletas publicas [EnCicla](http://www.encicla.gov.co/).

Soy colaborador en comunidades de software libre en la ciudad de Barranquilla entre ellas [PyBAQ](https://pybaq.co/), [FSLCol](http://fslcol.org/).

## Que tecnologías he aprendido

{% include tecnologias.html %}

## Sucesos relevantes

{% include timeline.html events=site.data.timeline %}
